-------------------
-- Oeuf de spawn --
-------------------
minetest.register_craftitem("mobs:sheep", {
	description = "Sheep",
	inventory_image = "spawn_sheep.png",
	wield_scale = {x = 1.25, y = 1.25, z = 2.5},
	groups = {},
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.add_entity(pointed_thing.above, "mobs:sheep")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			minetest.log("action", placer:get_player_name() .. " placed a sheep at " .. minetest.pos_to_string(pointed_thing.above) .. ".")
		end
		return itemstack
	end,
})

minetest.register_craftitem("mobs:slime", {
	description = "Slime",
	inventory_image = "spawn_slime.png",
	wield_scale = {x = 1.25, y = 1.25, z = 2.5},
	groups = {},
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.add_entity(pointed_thing.above, "mobs:slime")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			minetest.log("action", placer:get_player_name() .. " placed a slime at " .. minetest.pos_to_string(pointed_thing.above) .. ".")
		end
		return itemstack
	end,
})

minetest.register_craftitem("mobs:zombie", {
	description = "Zombie",
	inventory_image = "spawn_zombie.png",
	wield_scale = {x = 1.25, y = 1.25, z = 2.5},
	groups = {},
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.add_entity(pointed_thing.above, "mobs:zombie")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			minetest.log("action", placer:get_player_name() .. " placed a zombie at " .. minetest.pos_to_string(pointed_thing.above) .. ".")
		end
		return itemstack
	end,
})


minetest.register_craftitem("mobs:spider", {
	description = "Spider",
	inventory_image = "spawn_spider.png",
	wield_scale = {x = 1.25, y = 1.25, z = 2.5},
	groups = {},
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.add_entity(pointed_thing.above, "mobs:spider")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			minetest.log("action", placer:get_player_name() .. " placed a spider at " .. minetest.pos_to_string(pointed_thing.above) .. ".")
		end
		return itemstack
	end,
})


minetest.register_craftitem("mobs:creeper", {
	description = "Creeper",
	inventory_image = "spawn_creeper.png",
	wield_scale = {x = 1.25, y = 1.25, z = 2.5},
	groups = {},
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.add_entity(pointed_thing.above, "mobs:creeper")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			minetest.log("action", placer:get_player_name() .. " placed a creeper at " .. minetest.pos_to_string(pointed_thing.above) .. ".")
		end
		return itemstack
	end,
})

minetest.register_craftitem("mobs:herobrine", {
	description = "herobrine",
	inventory_image = "spawn_herobrine.png",
	groups = {not_in_creative_inventory=1},
	wield_scale = {x = 1.25, y = 1.25, z = 2.5},
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.add_entity(pointed_thing.above, "mobs:herobrine")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			minetest.log("action", placer:get_player_name() .. " placed a herobrine at " .. minetest.pos_to_string(pointed_thing.above) .. ".")
		end
		return itemstack
	end,
})

---------------------
-- Drop de monstre --
---------------------

minetest.register_craftitem("mobs:rotten_flesh", {
	description = "rotten flesh",
	inventory_image = "rotten_flesh.png",
	on_use = minetest.item_eat(2),
})

minetest.register_craftitem("mobs:meat_raw_sheep", {
	description = "Raw Mutton",
	inventory_image = "mutton_raw.png",
	on_use = minetest.item_eat(2),
})

minetest.register_craftitem("mobs:meat_cooked_sheep", {
	description = "Cooked Mutton",
	inventory_image = "mutton_cooked.png",
	on_use = minetest.item_eat(4),
})

minetest.register_craftitem("mobs:spider_eye", {
	description = "Spider Eye",
	inventory_image = "spider_eye.png",
	on_use = minetest.item_eat(2),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:meat_cooked_sheep",
	recipe = "mobs:meat_raw_sheep",
	cooktime = 25,
})

