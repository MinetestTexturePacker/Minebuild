head mineclone
====
Begin of little head